'use strict'

module.exports = [
  {
    id: 1,
    descricao: "Aluguel",
    valor: 500,
    tipo: "despesa"
  },
  {
    id: 2,
    descricao: "Mercado",
    valor: 1500,
    tipo: "despesa"
  },
  {
    id: 3,
    descricao: "Salario",
    valor: 5000,
    tipo: "receita"
  },
]